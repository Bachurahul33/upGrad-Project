function allPosts() 
{
    window.location.href= "./html/bloglist.html";
}

function newPosts() 
{
    document.getElementById('newPostModal').style.display='block';
}

function ClosePost() 
{
    document.getElementById('newPostModal').style.display='none';
}